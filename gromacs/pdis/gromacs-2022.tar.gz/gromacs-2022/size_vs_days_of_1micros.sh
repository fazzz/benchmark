#!/bin/sh

for pdis in pdis17 pdis18 pdis19 pdis20 pdis21 pdis22 pdis24 pdis25 pdis26; do 
    echo "size(# of atoms) days(1micros) ncpu" > size_vs_days_of_1micros_${pdis};
    if [ -f tmp_${pdis} ]; then
	rm tmp_${pdis}
    fi

    for f in `ls */cpu_vs_days_of_1micros_${pdis}`; do 
	d=`echo ${f} | awk -F"/" '{print $1}'`
	atom=`head -2 ${d}/input/*.gro | tail -1`

	awk 'BEGIN{min=1000;}{if($2<min){min=$2;nc=$1;}}END{print '${atom}', min, nc}' $f \
	    >> tmp_${pdis}; 
    done
    sort -nk 1,1 tmp_${pdis} >> size_vs_days_of_1micros_${pdis};
done
