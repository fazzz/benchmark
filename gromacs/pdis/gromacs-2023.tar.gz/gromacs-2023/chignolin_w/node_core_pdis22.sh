#!/bin/sh

nodes=( pdis22 )

declare -A cores=(
    ["pdis22"]="12 24"
)

declare -A line=(
    ["1"]="bench.job.pdis22_12"
    ["2"]="bench.job.pdis22_24"
)

gmx=/work20/yamamori/opt/gmx2023/bin/gmx_mpi

job_commonname=gx23_chgw
