#!/bin/sh

nodes=( pdis22 pdis24 pdis25 pdis26 )

declare -A cores=(
    ["pdis22"]="12 24"
    ["pdis24"]="16 32 48"
    ["pdis25"]="16 32 48 56"
    ["pdis26"]="16"
)

declare -A line=(
    ["1"]="bench.job.pdis22_12 bench.job.pdis24_16 bench.job.pdis25_16 bench.job.pdis26_16"
    ["2"]="bench.job.pdis22_24 bench.job.pdis24_32 bench.job.pdis25_32"
    ["3"]="bench.job.pdis24_48 bench.job.pdis25_48"
    ["4"]="bench.job.pdis25_56"
)

gmx=/work20/yamamori/opt/gmx2023/bin/gmx_mpi

job_commonname=gx23_SAM
