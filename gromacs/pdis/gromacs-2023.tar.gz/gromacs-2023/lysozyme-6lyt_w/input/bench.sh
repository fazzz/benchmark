#$ -S /bin/sh
#$ -V
#$ -q all.q@pdis17
#$ -j y
#$ -o production.o
#$ -cwd
#$ -N production

gmx_mpi_d grompp -f  production.mdp -p  topol.top -c  final_density_stabilization.gro -o  production.tpr

mpirun -np 16 gmx_mpi_d mdrun -deffnm production -maxh 0.1

