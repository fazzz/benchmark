#!/bin/sh

nodes=( pdis17 pdis18 pdis19 pdis20 )

declare -A cores=(
    ["pdis17"]="16 32"
    ["pdis18"]="16 32 64"
    ["pdis19"]="16 32 48"
    ["pdis20"]="16"
)

declare -A line=(
    ["1"]="bench.job.pdis17_16 bench.job.pdis18_16 bench.job.pdis19_16 bench.job.pdis20_16"
    ["2"]="bench.job.pdis17_32 bench.job.pdis18_32 bench.job.pdis19_32"
    ["3"]="bench.job.pdis18_64 bench.job.pdis19_48"
)

gmx=~/opt/bin/gmx_mpi

job_commonname=gx18_chgw
