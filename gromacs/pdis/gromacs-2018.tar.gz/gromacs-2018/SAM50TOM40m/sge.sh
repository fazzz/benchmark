#!/bin/sh

#$ -S /bin/sh
#$ -cwd
#$ -V
#$ -j y
#$ -q all.q

mpirun -np 32 gmx_mpi mdrun -deffnm SAM50TOM40m_s_1 -noconfout -maxh 0.25
